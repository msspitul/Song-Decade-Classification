###This below code can be used to adjust the width of the containers for display purposes.
#from IPython.display import display, HTML
#display(HTML("<style>.container { width:100% !important; }</style>"))

################################################################################
# Matthew Spitulnik ############################################################
# Natural Language Processing ##################################################
# Comparing Corpora with Corpus Statistics #####################################
# Project Summary: This project is a continuation of a previous project, Comparing
#  Corpora with Corpus Statistics (CCCS). For CCCS, the song lyrics from the 100 
# top billboard songs from each year between 1980 and 2019 were collected and 
# compiled into one data frame. They were then split into two groups, the years 
# before the year 2000, and the years after/including the year 2000. Some corpus 
# statistics were then performed on the words in each group of lyrics, which were 
# then analyzed to see if anything or any patterns stood out that seperated the 
# song lyrics before the year 2000 and the song lyrics including/after the year 
# 2000. For this assessment, the same collection of song lyrics will be utilized 
# to compare the lyrics before and after the year 2000, but different parts of 
# speech analysis will be applied to the text to identify and pull out lyrics 
# containting adjective/adverb part of speech phrases, determine the most common 
# adjectives/adverbs/nouns/verbs used in both time frames, and then perform 
# sentiment analysis on the data. Unlike in CCCS, the analysis of this data will 
# be performed and reported on within in this code file instead of a seperate 
# written report.
################################################################################

################################################################################
### Install and load required packages #########################################
################################################################################

###Install the required libraries.
#%pip install pandas
#%pip install re
#%pip install requests
#%pip install html5lib
#%pip install nltk
#%pip install contractions
#%pip install lxml
#%pip install bs4

#Import the required libraries
import pandas as pd
import re
import requests
import html5lib
import nltk
#import sys
#!{sys.executable} -m pip install contractions
import contractions
from nltk import FreqDist
from lxml import html
from urllib.request import urlopen
from urllib import request
from bs4 import BeautifulSoup
from nltk.stem import WordNetLemmatizer
from nltk.collocations import *
from nltk import sent_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer
nltk.download('vader_lexicon')
nltk.download('stopwords', quiet=True)

################################################################################
### Import the data sets that will be used throughout the code #################
################################################################################

###This creates a "default_directory" variable, where the directory path to the
# data files folder containing all of the required data sets is saved so that it
# does not need to be constantly re-entered. Remember to use forward slashes
# instead of back slashes in the directory path. For example, if the datafiles
# folder is saved in "C:\home\project\datafiles", then "C:/home/project"
# would be inserted between the quotes below.
default_directory = "<DEFAULT DIRECTORY PATH HERE>"

#load the data frames that were used in CCCS
songArtDF = pd.read_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDF.csv')
songArtDFOrg = pd.read_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDFOrg.csv')
songArtLyrics =pd.read_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtLyrics.csv')

################################################################################
### Perform Data Cleanup #######################################################
################################################################################

#make a copy of the song lyrics DF that I will use to turn everything into a sentence
songArtsent=songArtDFOrg.copy(deep=True)
songArtsent=songArtsent[songArtsent['Lyrics'] != '[]']

"""In the final data frame containing the song lyrics for each song, a categorical/factor 
variable was added that simply identified if each song was from before or after/in the year 2000."""

#make sure we have the correct number of songs with lyrics
print(songArtsent['Before2000'].value_counts()['Yes']) #1951 songs before 2000
print(songArtsent['Before2000'].value_counts()['No']) #1849 songs after/including 2000

"""In theory, since 40 years of the 100 top billboard songs were looked at, 
there should of been 40 x 100 songs with lyrics, for a total of 4000. 2000 songs 
before the year 2000, 2000 songs after/including the year 2000. Some different scripting 
techniques needed to be utilized to collect as much of the data as possible, and above 
shows that the lyrics could only be collected for 1951 of the songs before the year 2000, 
and the lyrics could be collected for 1849 of the songs after the year 2000."""

for i in range(0,3):
    print(songArtDF.loc[i,'Lyrics'])

"""The text for the song lyric data that was imported was still pretty raw and had not gone 
through any kind of cleaning process yet. The big issue in terms of clean up was going to be 
to format the data in a way that the song lyrics could be broken up into multiple sentences 
instead of just one long run on sentence. In the data above, the song lyrics from 3 songs are 
displayed. The lyrics for each song starts with an open bracket [ and concludes with a closed 
bracket ]. In between [ and ] are the song lyrics. Each line of the lyrics are surrounded by 
either single quotes '' or double quotes "", followed by a comma, unless it is the last line 
of a song, in which case the ' or " is followed by the ]. The nltk.sent_tokenize function, 
which is usd to break strings of text into individual sentences, looks for punctuation that is 
generally at the end of sentences, like periods . exclamation points ! and question marks ? to
accomplish this. When using nltk.sent_tokenize, wherever these types of punctuation exist is 
where a sentence is viewed as ending.

Since this punctuation did not exist in the song lyric text, something would need to be done 
to get one of these line-ending-types of punctuation inserted where each lyrical line ended. 
The first thought was to replace some of the different line break markers like '\n' or '\r' 
with a period. It was quickly discovered however that in many of the song lyric texts, these 
line break markers only appeared at the beginning or the end of the entire song lyric, not 
in between each line. The next obersvation was that each line in a lyric appeared to start 
with a capital letter, so if regex could be used to find every capital letter in the song 
lyrics, a period could be inserted before it, and then nltk.sent_tokenize could identify 
where the sentence before it ended. Unfortunately after further investgation it was 
determined that this capital letter pattern was not consistent, with other words throughout 
song lyrics containing capital letters even though they weren't the first word. Any sentence 
that had some form of 'I' throughout it would also throw off this pattern.

It seemed like the best course of action was to use the observation stated above, that 
each line of a lyric was surrounded by '' or "" followed by a comma. This pattern appeared 
to be consistent in every song lyric that was studied. There also did not appear to be any 
stray instances of ', or ", appearing in a location that was not at the end of a 
line/sentence. Even if an abbreviated or slang word like talkin' appeared at the end of 
a line, it would still be followed by another single or double quote, then a comma, 
appearing as so: talkin'', or talkin'",. The script that is created to place the period 
would still just replace the ', or ", with a period. With that figured out, the following 
steps were taken to clean up the data:

1) Remove line break text like \n and \r or excessive backslashes like \\.
2) Replace contractions like can't and don't with cannot and do not so that punctuation 
can later be easily removed without losing the meaning of words.
3) Replace all instances of ', with a period . to signify the end of a line.
4) Replace all instances of ", with a period . to signify the end of a line.
5) Replace all instances of '] and "] at the end of a song's lyrics with a period.
6) Seperate the lyrics into two lists, the lyrics for songs before the year 2000 and the 
lyrics for songs after/including the year 2000.
7) Split the songs lyrics for before 2000 into individual sentences, which was compiled 
into a list of all the sentences.
8) Split the songs lyrics for after 2000 into individual sentences, which was compiled 
into a list of all the sentences.

Additional data manipulation that was performed will be explained further down in the code.
"""

#remove line breaks again like I did in CCCS
for i in songArtsent.index:
    songArtsent.loc[i,'Lyrics']=songArtsent.loc[i,'Lyrics'].replace('\\n','')
    songArtsent.loc[i,'Lyrics']=songArtsent.loc[i,'Lyrics'].replace('\\r','')
    songArtsent.loc[i,'Lyrics']=songArtsent.loc[i,'Lyrics'].replace('\\','')

#remove contractions again so other punctation can be easily removed later
for i in songArtsent.index:
    songArtsent.loc[i,'Lyrics']=contractions.fix(songArtsent.loc[i,'Lyrics'])

for i in range(0,10):
    print(songArtsent.loc[i,'Lyrics'])

####next few cells are test regex searches

for i in range(8,9):
    apostrapheReplaceTest=re.findall('[\',]',songArtsent.loc[i,'Lyrics'])

apostrapheReplaceTest

for i in range(8,9):
    apostrapheReplaceTest=re.findall('\'[\',]',songArtsent.loc[i,'Lyrics'])

apostrapheReplaceTest

for i in range(8,9):
    apostrapheReplaceTest=re.findall('\'[^,]',songArtsent.loc[i,'Lyrics'])

apostrapheReplaceTest

######now do some sub regex testing
re.sub('\'[\",]','.',songArtsent.loc[8,'Lyrics'])

re.sub('\",','.',songArtsent.loc[8,'Lyrics'])

re.sub('\'[\',]','.',songArtsent.loc[0,'Lyrics'])

re.sub('\',','.',songArtsent.loc[0,'Lyrics'])

####now run the sub regex statement to replace '\',' with a '.'
for i in songArtsent.index:
    songArtsent.loc[i,'Lyrics']=re.sub('\',','.',songArtsent.loc[i,'Lyrics'])

songArtsent.loc[0,'Lyrics']

songArtsent.loc[8,'Lyrics']

####now run the sub regex statement to replace '\",' with a '.'
for i in songArtsent.index:
    songArtsent.loc[i,'Lyrics']=re.sub('\",','.',songArtsent.loc[i,'Lyrics'])

songArtsent.loc[0,'Lyrics']

songArtsent.loc[8,'Lyrics']

#now test removing the ']' at the end of each song's lyrics
re.sub('\']','.',songArtsent.loc[0,'Lyrics'])

re.sub('\"]','.',songArtsent.loc[8,'Lyrics'])

####now  replace '']' and '"]' with a '.'
for i in songArtsent.index:
    songArtsent.loc[i,'Lyrics']=re.sub('\']','.',songArtsent.loc[i,'Lyrics'])

for i in songArtsent.index:
    songArtsent.loc[i,'Lyrics']=re.sub('\"]','.',songArtsent.loc[i,'Lyrics'])

songArtsent.to_csv(f'{default_directory}/Sentiment and Exploratory Analysis/datafiles/songArtsent.csv',index=False)

#combine all the lyrics into two lists of lyrics, before 2000 and after 2000.
before2000lyr=[]
after2000lyr=[]
for i in songArtsent.index:
    if songArtsent.loc[i,'Before2000']=='Yes':
        before2000lyr.append(songArtsent.loc[i,'Lyrics'])
    else:
        after2000lyr.append(songArtsent.loc[i,'Lyrics'])

print(before2000lyr[:3])

#split the Before Lyrics into sentences
BLSplit = nltk.sent_tokenize(str(before2000lyr))

print(BLSplit[0:12])

print(BLSplit[10:11])

print(BLSplit[11:12])

#split the After Lyrics into sentences
ALSplit = nltk.sent_tokenize(str(after2000lyr))

print(ALSplit[:10])

print(ALSplit[0:1])

print(ALSplit[1])

len(BLSplit)

BLSplit[92223]

BLSplit[92222]

BLSplit[len(BLSplit)-1:len(BLSplit)]

"""Now that the before 2000 and after 2000 lyrics had been broken up into individual 
sentences, punctuation was no longer needed within the text. Because of how the 
punctuation lined up after some of the above clean up was performed, some entries in 
the list of lyric sentences only contained punctuation, so these entries were blank 
after the punctuation removal and were subsequently removed from the lists of before 
2000 sentences and after 2000 sentences. What remained was 77891 sentences from lyrics 
before the year 2000 and 111133 sentences from lyrics after the year 2000. This was 
interesting to see, since lyrics for over 100 more songs before the year 2000 were 
found than lyrics for songs after the year 2000, and yet the lyrics for songs after 
the year 2000 resulted in over 30000 more sentences. This translated to about 40 lines 
per song before 2000 and about 60 lines per song after the year 2000."""

#now that the lyrics have been split up into sentects, remove all of the punctuation
#first the before lyrics
for i in range(0,len(BLSplit)):
    BLSplit[i]=re.sub(r'[^\w\s]','',BLSplit[i])

BLSplit[92223]

len(BLSplit)

for i in range(92210,len(BLSplit)):
    print(BLSplit[i])

#Remove before lyrics list entries that are blank
for i in range(92210,len(BLSplit)):
    if BLSplit[i]!='':
        print('List entry: ', i, ' || ', BLSplit[i])

BLSplitR=[]
for i in range(0,len(BLSplit)):
    if BLSplit[i]!='':
        BLSplitR.append(BLSplit[i])

len(BLSplitR)

for i in range(77770,len(BLSplitR)):
    if BLSplitR[i]!='':
        print('List entry: ', i, ' || ', BLSplitR[i])

#Remove punctuation in after lyrics
for i in range(0,len(ALSplit)):
    ALSplit[i]=re.sub(r'[^\w\s]','',ALSplit[i])

len(ALSplit)

#Remove punctuation in after lyrics
for i in range(129600,len(ALSplit)):
    print(ALSplit[i])

ALSplitR=[]
for i in range(0,len(ALSplit)):
    if ALSplit[i]!='':
        ALSplitR.append(ALSplit[i])

len(ALSplitR)

################################################################################
### Perform Data Analysis ######################################################
################################################################################

#figure out how many lines per song, on average, for before and after 2000
#number of songs with lyrics before 2000: 1951
#number of songs with lyrics after 2000: 1849

print('Average number of lines per song before the year 2000:', len(BLSplitR) / 1951)
print('Average number of lines per song after the year 2000:', len(ALSplitR) / 1849)

for i in range(111100,len(ALSplitR)):
    print(ALSplitR[i])

"""Now that the lyrics were broken into individual sentences and cleaned up, steps needed 
to be taken to identify the words that make up different parts of speech within each 
sentence. To do this, each sentence in the before 2000 list and the after 2000 list 
needed to be tokenized once again to break them down into individual words. This resulted 
in a list of lists, with the overall list containing the lyrics of each individual song, 
and then within each song list entry, each lyric line was was another list with each word 
as an entry. For example, one song now appeared like this:

[['Colour', 'me', 'your', 'colour', 'baby'], ['Colour', 'me', 'your', 'car'], 
['Colour', 'me', 'your', 'colour', 'darling'], ['I', 'know', 'who', 'you', 'are'], 
['Come', 'up', 'off', 'your', 'colour', 'chart'], ['I', 'know', 'where', 'you', 'are', 'comin', 'from'], 
['Call', 'me', 'call', 'me', 'on', 'the', 'line'], ['Call', 'me', 'call', 'me', 'any', 'anytime'], 
['Call', 'me', 'call', 'me', 'my', 'love'], ['You', 'can', 'call', 'me', 'any', 'day', 'or', 'night']]

Next, all words, except for "I", were changed to be lowercase, so a word at the beginning 
of a sentence that was capitalized would be counted just the same as if it was in the middle 
of a sentence. Next, nltk.pos_tag was applied to both lists of lyric words, which took every 
single word, identified it's part of speech, then created tuples for each word containing the 
word and the symbol for its part of speech. The information now appeared like this:

[[('colour', 'VB'), ('me', 'PRP'), ('your', 'PRP$'), ('colour', 'NN'), ('baby', 'NN')], 
[('colour', 'VB'), ('me', 'PRP'), ('your', 'PRP$'), ('car', 'NN')]]
"""

# Apply the word tokenizer to each sentence in the Before Lyrics
BLtoken = [nltk.word_tokenize(sent) for sent in BLSplitR]
print(BLtoken[:10])
#the output is a list of strings that contains the sentences
print(type(BLtoken))
len(BLtoken)

# Apply the word tokenizer to each sentence in after lyrics
ALtoken = [nltk.word_tokenize(sent) for sent in ALSplitR]
print(ALtoken[:10])
#the output is a list of strings that contains the sentences
print(type(ALtoken))
len(ALtoken)

#now make everything the same case, except for "I"
#before lyrics first
for i in range(0,len(BLtoken)):
    for h in range(0,len(BLtoken[i])):
        if BLtoken[i][h] != 'I':
            BLtoken[i][h]=BLtoken[i][h].lower()

#now make everything the same case, except for "I"
#now after lyrics
for i in range(0,len(ALtoken)):
    for h in range(0,len(ALtoken[i])):
        if ALtoken[i][h] != 'I':
            ALtoken[i][h]=ALtoken[i][h].lower()

print(ALtoken[:10])

## POS Tagging, to retrieve adjective (JJs) and adverb (RBs) tags

# use the Stanford POS tagger to POS tag tokens of each sentence in the Before Lyrics
# this is the default tagger in nltk
BLtagged = [nltk.pos_tag(tokens) for tokens in BLtoken]

print(BLtagged[:2])

print(len(BLtagged))
print(len(BLtoken))

# use the Stanford POS tagger to POS tag tokens of each sentence in the After Lyrics
# this is the default tagger in nltk
ALtagged = [nltk.pos_tag(tokens) for tokens in ALtoken]

print(ALtagged[:100])

"""Now that the parts of speech of each word had been tagged, information could be 
pulled out to analyze. First, adjective phrases (a phrase containing an adverb and 
adjective) were pulled out from both the before 2000 and after 2000 lyric lists. 
The number of times each adjective phrase appeared in both lists was tallied together 
using a frequency distribution, which could then be used to compare the two different 
time periods of lyrics. For both the before 2000 and after 2000 lyrics, the most 
common adjective phrase was "so much". In fact, for both periods of time, the top 12 
adjective phrases started with either the word "so" or "too". Of those top 12 phrases, 
7 of them showed up in the top 12 for both the before 2000 and after 2000 list. For 
both lists, the first phrase that showed up that didn't start with either "so" or "too" 
was "not gon", which is presumably an abbreviated form of "not going to". In both 
lists, 46 of the 50 phrases started with either "so", "too", or "not". Overall 
though, only 28 of the top 50 adjective phrases in the before 2000 list matched the 
top 50 adjective phrases from the after list."""

# Following our NLTK textbook, chapter on Information Extraction--Chunking (https://www.nltk.org/book/ch07.html)

# Using CHUNKING to parse sentences
# to look for "adjective phrases", i.e. phrases (or chunks) that have adverbs and adjectives ('RB'+'JJ')
# First step: writing a grammar that defines the POS in the chunk
# we name this grammar "ADJPH" ("ADJective PHrase") using regexes

#import re #already done in the beginning
grammar_adjph = "ADJPH: {<RB.?>+<JJ.?>}"
# This regex reads as: "find groups ("< >") of RBs (adverbs) together with groups of JJs (adjectives), with groups defineds as
# RBs with any ending (the "." is a placeholder or wildcard for the "R" and the "S" at the end of RBR and RBS,
# while "?" indicates "optional character" so RB can be found alone as well). Same regex operators apply to JJs.

# Second step: import the nltk parser to process each sentence
chunk_parser_adj = nltk.RegexpParser(grammar_adjph)

#first the before lyrics
B_adjph_tags = []
for sent in BLtagged:
    if len(sent) > 0:
        tree = chunk_parser_adj.parse(sent)
        for subtree in tree.subtrees():
            if subtree.label() == 'ADJPH':
                B_adjph_tags.append(subtree)

# Visualizing the actual adjective phrase
B_adjective_phrases = []
for sent in B_adjph_tags:
    temp = ''
    for w, t in sent:
        temp += w+ ' '
    B_adjective_phrases.append(temp)

print('First 10 adjective phrases for lyrics before 2000: ', B_adjective_phrases[:10])


# Following our NLTK textbook, chapter 1 on Language Processing (https://www.nltk.org/book/ch01.html)

## FREQUENCY DISTRIBUTIONS
# Top 50 adjective phrases
B_freq_adjph = nltk.FreqDist(B_adjective_phrases)

print('Top adjective phrases by frequency for lyrics before 2000: ')
B_adj_phrase_list=[]
for word, freq in B_freq_adjph.most_common(50):
    #create a list of the most common phrases to use for comparison later
    B_adj_phrase_list.append(word)
    print(word, freq)


#print the list of our sentences:
print('Length of adjective phrase sentences for lyrics before 2000: ', len(B_adjph_tags))

#Now the after lyrics
A_adjph_tags = []
for sent in ALtagged:
    if len(sent) > 0:
        tree = chunk_parser_adj.parse(sent)
        for subtree in tree.subtrees():
            if subtree.label() == 'ADJPH':
                A_adjph_tags.append(subtree)

# Visualizing the actual adjective phrase
A_adjective_phrases = []
for sent in A_adjph_tags:
    temp = ''
    for w, t in sent:
        temp += w+ ' '
    A_adjective_phrases.append(temp)

print('First 10 adjective phrases for lyrics after 2000: ', A_adjective_phrases[:10])


# Following our NLTK textbook, chapter 1 on Language Processing (https://www.nltk.org/book/ch01.html)

## FREQUENCY DISTRIBUTIONS
# Top 50 adjective phrases
A_freq_adjph = nltk.FreqDist(A_adjective_phrases)

print('Top adjective phrases by frequency for lyrics after 2000: ')
A_adj_phrase_list=[]
for word, freq in A_freq_adjph.most_common(50):
    #create a list of the most common phrases to use for comparison later
    A_adj_phrase_list.append(word)
    print(word, freq)


#print the list of our sentences:
print('Length of adjective phrase sentences for lyrics after 2000: ', len(A_adjph_tags))

#####check to see how many phrases are in common for each of the lists
#adjective phrase lists
adj__phrase_common = sum(i in B_adj_phrase_list for i in A_adj_phrase_list)
print(adj__phrase_common)

"""Next, the adverb phrases for before and after the year 2000 lyrics were looked at.
For both lists of lyrics, the term "not even" is the most frequent adverb phrases, 
and for both lists, 24 of the 50 phrases started with either "so"or "not". 6 of the 
top 10 most frequent adverb phrases in the before 2000 list matched top 10 most 
frequent adverb phrases in the after list. One phrase in the top 10 most frequent 
adverb phrases in the before 2000 list, "once again", didn't show up anywhere in 
the top 50 most freqent adverb phrases in the after 2000 list. Four of the top 10 
most frequent adverb phrases in the after 2000 list, "over again", "up all", 
"so just", and "down down", didn't show up anywhere in the top 50 most frequent 
adverb phrases in the before 2000 list. In all, however, 32 of the 50 top adverb 
phrases in each list matched, 4 more matching phrases than the adjective list."""

# Now we look for "adverb phrases" or chunks that have 2 consecutive adverbs ('RB')
# First step: writing a grammar that defines POS rules of the adverb phrase the chunk
# we name this grammar "ADVPH" ("ADVerb PHrase")
grammar_advph = "ADVPH: {<RB>+<RB>}"

# Second step: import the nltk parser to process each sentence
chunk_parser_adv = nltk.RegexpParser(grammar_advph)

#first the lyrics before 2000
B_advph_tags = []
for sent in BLtagged:
    if len(sent) > 0:
        tree = chunk_parser_adv.parse(sent)
        for subtree in tree.subtrees():
            if subtree.label() == 'ADVPH':
                B_advph_tags.append(subtree)

# Visualizing the actual adjective phrase
B_adverb_phrases = []
for sent in B_advph_tags:
    temp = ''
    for w, t in sent:
        temp += w+ ' '
    B_adverb_phrases.append(temp)

print('First 10 adverb phrases for before lyrics: ', B_adverb_phrases[:10])

# top 50 adjective phrases
B_freq_advph = nltk.FreqDist(B_adverb_phrases)

print('Top adverb phrases by frequency for before lyrics: ')
B_adv_phrase_list=[]
for word, freq in B_freq_advph.most_common(50):
    #create a list of the most common phrases to use for comparison later
    B_adv_phrase_list.append(word)
    print(word, freq)


#print the list of our sentences:
print('Length of adverb phrase sentences for before lyrics: ', len(B_advph_tags))

#now the lyrics after 2000
A_advph_tags = []
for sent in ALtagged:
    if len(sent) > 0:
        tree = chunk_parser_adv.parse(sent)
        for subtree in tree.subtrees():
            if subtree.label() == 'ADVPH':
                A_advph_tags.append(subtree)

# Visualizing the actual adjective phrase
A_adverb_phrases = []
for sent in A_advph_tags:
    temp = ''
    for w, t in sent:
        temp += w+ ' '
    A_adverb_phrases.append(temp)

print('First 10 adverb phrases for after lyrics: ', A_adverb_phrases[:10])

# top 50 adjective phrases
A_freq_advph = nltk.FreqDist(A_adverb_phrases)

print('Top adverb phrases by frequency for after lyrics: ')
A_adv_phrase_list=[]
for word, freq in A_freq_advph.most_common(50):
    #create a list of the most common phrases to use for comparison later
    A_adv_phrase_list.append(word)
    print(word, freq)


#print the list of our sentences:
print('Length of adverb phrase sentences for after lyrics: ', len(A_advph_tags))

#####check to see how many phrases are in common for each of the lists
#adjective phrase lists
adv__phrase_common = sum(i in B_adv_phrase_list for i in A_adv_phrase_list)
print(adv__phrase_common)

"""Next, the top 50 single adjectives, adverbs, nouns, and verbs were looked at 
for both the before 2000 and after 2000 lists. 7 of the top 10 most common 
adjectives in the before 2000 list were also in the top 10 of the after 2000 list, 
and the top 2 of each list were the exact same (good, little). Overall, 42 
adjectives matched in each list. All 10 of the most common adverbs from the before 
2000 list were also the top 10 most common in the after 2000 list, and the top 6 of 
each list matched exactly (not, so, just, now, never, here). Overall, 43 of the 
adjectives in each list matched. 8 of the top 10 most common nouns in the before 
2000 list matched the list of top 10 nouns in the after 2000 list, with 5 of the 
nouns landing in the exact same rank of frequency (you, it, me, my, baby). Overall, 
44 nouns were in both lists of top 50. 9 of the 10 top most common verbs in the 
before 2000 list were also in the top 10 of the after list, with only the top word, 
"is", landing at the same spot in the frequency ranking. 45 of the 50 words in each 
list matched, however. Not surprisingly, the single list of words for the before 
and after lyrics had a higher percentage of matches then the list of adjective/adverb 
phrases that matched. The probably of one word occuring in two different lists of 
text in general will be more likely than two words appearing consecutively in both lists."""

# Top 50 adjective tokens for the before lyrics

B_adjective_tokens = []
for sentence in BLtagged:
    for word, pos in sentence:
        if pos in ['JJ', 'JJR', 'JJS']: # adjective, comparative, superlative
            if len(word)>1:
                B_adjective_tokens.append(word)
B_freq_adjective = nltk.FreqDist(B_adjective_tokens)

B_adj_list=[]
for word, freq in B_freq_adjective.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    B_adj_list.append(word)
    print(word,freq)

# Top 50 adjective tokens for the after lyrics

A_adjective_tokens = []
for sentence in ALtagged:
    for word, pos in sentence:
        if pos in ['JJ', 'JJR', 'JJS']: # adjective, comparative, superlative
            if len(word)>1:
                A_adjective_tokens.append(word)
A_freq_adjective = nltk.FreqDist(A_adjective_tokens)

A_adj_list=[]
for word, freq in A_freq_adjective.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    A_adj_list.append(word)
    print(word,freq)

# Top 50 adverb tokens for the before lyrics

B_adverb_tokens = []
for sentence in BLtagged:
    for word, pos in sentence:
        if pos in ['RB', 'RBR', 'RBS']: # adverb, comparative, superlative
            if len(word)>1:
                B_adverb_tokens.append(word)
B_freq_adverb = nltk.FreqDist(B_adverb_tokens)

B_adv_list=[]
for word, freq in B_freq_adverb.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    B_adv_list.append(word)
    print(word,freq)

# Top 50 adverb tokens for the after lyrics

A_adverb_tokens = []
for sentence in ALtagged:
    for word, pos in sentence:
        if pos in ['RB', 'RBR', 'RBS']: # adverb, comparative, superlative
            if len(word)>1:
                A_adverb_tokens.append(word)
A_freq_adverb = nltk.FreqDist(A_adverb_tokens)

A_adv_list=[]
for word, freq in A_freq_adverb.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    A_adv_list.append(word)
    print(word,freq)

# Top 50 noun tokens for the before lyrics

B_noun_tokens = []
for sentence in BLtagged:
    for word, pos in sentence:
        if pos in ['NN', 'NNS', 'NNP', 'NNPS', 'PRP', 'PRP$', 'WP', 'WP$']: 
                # noun, plural, proper, proper plural, personal pronoun, possesive pronoun, WH pronoun, poss WH pronoun
            if len(word)>1:
                B_noun_tokens.append(word)
B_freq_noun = nltk.FreqDist(B_noun_tokens)

B_nn_list=[]
for word, freq in B_freq_noun.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    B_nn_list.append(word)
    print(word,freq)

# Top 50 noun tokens for the after lyrics

A_noun_tokens = []
for sentence in ALtagged:
    for word, pos in sentence:
        if pos in ['NN', 'NNS', 'NNP', 'NNPS', 'PRP', 'PRP$', 'WP', 'WP$']: 
                # noun, plural, proper, proper plural, personal pronoun, possesive pronoun, WH pronoun, poss WH pronoun
            if len(word)>1:
                A_noun_tokens.append(word)
A_freq_noun = nltk.FreqDist(A_noun_tokens)

A_nn_list=[]
for word, freq in A_freq_noun.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    A_nn_list.append(word)
    print(word,freq)

# Top 50 verbs tokens for the before lyrics

B_verb_tokens = []
for sentence in BLtagged:
    for word, pos in sentence:
        if pos in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ']: 
            # verb, past verb, part gerund verb, verb past part, verb non-3rd, verb 3rd
            if len(word)>1:
                B_verb_tokens.append(word)
B_freq_verb = nltk.FreqDist(B_verb_tokens)

B_vb_list=[]
for word, freq in B_freq_verb.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    B_vb_list.append(word)
    print(word,freq)

# Top 50 verbs tokens for the after lyrics

A_verb_tokens = []
for sentence in ALtagged:
    for word, pos in sentence:
        if pos in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ']: 
            # verb, past verb, part gerund verb, verb past part, verb non-3rd, verb 3rd
            if len(word)>1:
                A_verb_tokens.append(word)
A_freq_verb = nltk.FreqDist(A_verb_tokens)

A_vb_list=[]
for word, freq in A_freq_verb.most_common(50):
    #create a list I can later use to compare number of words that are similar in before and after
    A_vb_list.append(word)
    print(word,freq)

#####check to see how many words are in common for each of the lists
#adjective lists
adj_common = sum(i in B_adj_list for i in A_adj_list)
print(adj_common)

#adverb lists
adv_common = sum(i in B_adv_list for i in A_adv_list)
print(adv_common)

#noun lists
nn_common = sum(i in B_nn_list for i in A_nn_list)
print(nn_common)

#verb lists
vb_common = sum(i in B_vb_list for i in A_vb_list)
print(vb_common)

"""Next, the number of sentences overall that had adjective phrases, adverb phrases, 
or one of an adjective or adverb phrases, were looked at for the before 2000 and 
the after 2000 lists. Since there were a different number of total sentences for 
the before list and after list, the percentage of each list was used for a better 
comparison. 10% of both the before 2000 and after 2000 lists contained adjective 
phrases. About 8% of the before 2000 sentences contained an adverb phrase, while 
the percentage of after 2000 sentences with an adverb phrase was slightly higher 
at about 9%. About 11% of the before 2000 sentences had either an adjective or 
adverb phrase, while about 12% of the after 2000 sentences sentences had either 
an adjective or adverb phrase. Even though the percentage of adverb phrases and 
adjective or adverb phrases was slightly higher for the after 2000 sentences, 
overall the percentage for both was pretty close."""

# Now we have two lists of POS tags combinations we can compare
# We need to get the sentences back from the tagging exercise and run some stats

#first the before lyrics
# Create a list of original sentences from the ADJECTIVE phrase subset:
B_adjph_whole_sentences = []

# loop over the sentences in the adjective phrase sentences we created:
for sents in B_adjph_tags:
    temp=''
    for (word,tag) in sents:
        temp += word+' '
        B_adjph_whole_sentences.append(temp)

print(len(B_adjph_whole_sentences))
#since the total number of sentences is different for before and after lyrics, 
# normalize this number for better comparisons
print(len(B_adjph_whole_sentences)/len(BLtagged))

#now the after lyrics
# Create a list of original sentences from the ADJECTIVE phrase subset:
A_adjph_whole_sentences = []

# loop over the sentences in the adjective phrase sentences we created:
for sents in A_adjph_tags:
    temp=''
    for (word,tag) in sents:
        temp += word+' '
        A_adjph_whole_sentences.append(temp)

print(len(A_adjph_whole_sentences))
#normalized
print(len(A_adjph_whole_sentences)/len(ALtagged))

# Create a list of original sentences from the ADVERB phrase subset:
#first the before lyrics
B_advph_whole_sentences = []

# loop over the sentences in the adjective phrase sentences we created:
for sents in B_advph_tags:
    temp=''
    for (word,tag) in sents:
        temp += word+' '
        B_advph_whole_sentences.append(temp)

print(len(B_advph_whole_sentences))
#normalized
print(len(B_advph_whole_sentences)/len(BLtagged))

# Create a list of original sentences from the ADVERB phrase subset:
#now the after lyrics
A_advph_whole_sentences = []

# loop over the sentences in the adjective phrase sentences we created:
for sents in A_advph_tags:
    temp=''
    for (word,tag) in sents:
        temp += word+' '
        A_advph_whole_sentences.append(temp)

print(len(A_advph_whole_sentences))
#normalized
print(len(A_advph_whole_sentences)/len(ALtagged))

# Combine lists together to have a single list of adjective/adverb phrases:
# Useful to know which sentences are heavy in qualifiers

#first the before lyrics
# create a new variable to store all adjective phrase sentences
#B_adv_adj_phrase_sentences = B_adjph_whole_sentences #this is changing the original list, need to make a copy instead
B_adv_adj_phrase_sentences = B_adjph_whole_sentences.copy()

# iterate over adverb phrase sentences
for sent in B_advph_whole_sentences:
    # if a sentence is not in the adjective phrases list imported
    if sent not in B_adv_adj_phrase_sentences:
        # attach that sentence
        B_adv_adj_phrase_sentences.append(sent)

# print the lenght of the list (i.e. number of sentences with both adjective and adverb phrases) for the before lyrics
print(len(B_adv_adj_phrase_sentences))
#normalized
print(len(B_adv_adj_phrase_sentences)/len(BLtagged))

len(B_adjph_whole_sentences)

#now the after lyrics
# create a new variable to store all adjective phrase sentences
#A_adv_adj_phrase_sentences = A_adjph_whole_sentences #this is changing the original list, need to make a copy instead
A_adv_adj_phrase_sentences = A_adjph_whole_sentences.copy()

# iterate over adverb phrase sentences
for sent in A_advph_whole_sentences:
    # if a sentence is not in the adjective phrases list imported
    if sent not in A_adv_adj_phrase_sentences:
        # attach that sentence
        A_adv_adj_phrase_sentences.append(sent)

# print the lenght of the list (i.e. number of sentences with both adjective and adverb phrases) for the before lyrics
print(len(A_adv_adj_phrase_sentences))
#normalized
print(len(A_adv_adj_phrase_sentences)/len(ALtagged))

len(A_adjph_whole_sentences)

"""Next, the average length of sentences was compared. The average length of 
overall sentences before 2000 was about 31 characters, while it was about 33 
characters for the after 2000 sentences. The average length of adjective 
phrases in the before and after lyrics was about 7.3 characters. The average 
length of adverb phrases for the before sentences was about 8 characters, 
while adverb phrases in the after list were about 8.1 characters. For both 
the before 2000 and after 2000 lists, we can see that that the adverb 
phrases were about 1 character longer."""

# Following our NLTK textbook, Writing Structural Programs chapter
# section on Procedural vs Declarative style (http://www.nltk.org/book_1ed/ch04.html)

## CORPUS STATISTICS--SENTENCES LENGTH

# Calculating the average length of sentences in the before lyrics
# from http://www.nltk.org/book_1ed/ch04.html
total_before = sum(len(sent) for sent in BLSplitR) # remember: 'BLSplitR' is our before lyrics split into sentences
print(total_before / len(BLSplitR))

# Calculating the average length of sentences in the after lyrics
# from http://www.nltk.org/book_1ed/ch04.html
total_after = sum(len(sent) for sent in ALSplitR) # remember: 'ALSplitR' is our after lyrics split into sentences
print(total_after / len(ALSplitR))

# Calculate the average length of an adjective phrase sentence in the before lyrics
# We can then compare the average length of the adjective phrases to
# the average sentences we calculated for all sentences in the before lyrics
B_total_adjph_sentences = sum(len(sent) for sent in B_adjph_whole_sentences) # B_adjph_whole_sentences stores our adjective phrases in the before lyrics
print(B_total_adjph_sentences / len(B_adjph_whole_sentences))

# Calculate the average length of an adjective phrase sentence in the after lyrics
# We can then compare the average length of the adjective phrases to
# the average sentences we calculated for all sentences in the after lyrics
A_total_adjph_sentences = sum(len(sent) for sent in A_adjph_whole_sentences) # A_adjph_whole_sentences stores our adjective phrases in the after lyrics
print(A_total_adjph_sentences / len(A_adjph_whole_sentences))

# Calculate the average length of an adverb phrase sentence in the before lyrics
# We can then compare the average length of the adverb phrases to
# the average sentences we calculated for all sentences in the before lyrics
B_total_advph_sentences = sum(len(sent) for sent in B_advph_whole_sentences) # B_advph_whole_sentences stores our adverb phrases in the before lyrics
print(B_total_advph_sentences / len(B_advph_whole_sentences))

# Calculate the average length of an adverb phrase sentence in the after lyrics
# We can then compare the average length of the adjective phrases to
# the average sentences we calculated for all sentences in the after lyrics
A_total_advph_sentences = sum(len(sent) for sent in A_advph_whole_sentences) # A_advph_whole_sentences stores our adverb phrases in the after lyrics
print(A_total_advph_sentences / len(A_advph_whole_sentences))

"""Finally, sentiment analysis were performed on the sentences overall for the 
before and after lists, aswell as the adjective phrases, adverb phrases, and 
adjective/adverb phrases. The sentiment analysis output has 4 values: negative, 
positive, neutral, and compound. The negative, positive, and neutral values 
show what percent of words in a sentence are considered either negative, positive, 
and neutral, and will always add up to 1 (or 100%). The compound value will be 
between -1 and 1, with scores closer to -1 showing a sentence is more on the 
negative side, scores closer to 1 showing that a sentence is on the positive 
side, and a score closer to 0 showing that a sentence is more neutral.

The sentiment analysis for the overall lines of lyrics before 2000 were .06 
negative, .13 positive, and .81 neutral, with a compound score of about .08. 
The overall scores for the after 2000 lyrics were .07 negative, .12 positive, 
.81 neutral, and a compound score of .05.

For the adjective phrases in the before 2000 lines of lyrics, about .06 were 
negative, .09 were positive, and .85 were neutral, with a compound score of 
about .02. The after 2000 adjective phrase lines of lyrics had scores of about 
.08 negative, .08 positive, and .84 neutral, with a compound score of .008.

For the adverb phrases in the before 2000 lines of lyrics, about .02 were 
negative, .06 were positive, and .92 were neutral, with a compound score of 
about .02. The after 2000 adverb phrase lines of lyrics also had scores of 
about .02 negative, .06 positive, and .92 neutral, with a compound score of .01.

For the adjective/adverb phrases in the before 2000 lines of lyrics, about .06 
were negative, .1 were positive, and .84 were neutral, with a compound score of 
about .02. The after 2000 adjective/adverb phrase lines of lyrics also had scores 
of about .07 negative, .08 positive, and .85 neutral, with a compound score of .009.

The overall sentences in the before and after 2000 lists had the highest percent 
of positive words, with the percentage of positive words almost twice as high as 
the percentage of negative words. The before and after adverb phrases had the 
highest percentage of neutral words at about .92. The overall before/after 2000 
sentences, before/after adjective phrases, and before/after adjective/adverb phrases 
all had negative scores in the .06-.08 range. Only the before/after adverb phrases 
had negative percentages that were lower, both of which were about .02. Based on 
the high neutral score of all the anaylsis, and the close to zero compound scores, 
all of the lines in the song lyrics appear to balance out to being neutral. At the 
same time though, they all have higher percentage of positive words then negative words.
"""

#now perform sentiment analysis on before lyrics and after lyrics using the list of before sentences and after sentences
#before sentiment analysis

sid = SentimentIntensityAnalyzer()

BeforeSentAnalysis=pd.DataFrame()

for i in range(0,len(BLSplitR)):
    sent=sid.polarity_scores(BLSplitR[i])

    B_Sent=BLSplitR[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[B_Sent, Neg, Pos, Neu, Comp]
    TempBSent = pd.DataFrame([TimeForDF],columns=('B_Sent','Negative', 'Positive','Neutral','Compound'))
    CombBSent=[BeforeSentAnalysis,TempBSent]
    BeforeSentAnalysis=pd.concat(CombBSent)

BeforeSentAnalysis

AfterSentAnalysis=pd.DataFrame()

for i in range(0,len(ALSplitR)):
    sent=sid.polarity_scores(ALSplitR[i])

    A_Sent=ALSplitR[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[A_Sent, Neg, Pos, Neu, Comp]
    TempASent = pd.DataFrame([TimeForDF],columns=('A_Sent','Negative', 'Positive','Neutral','Compound'))
    CombASent=[AfterSentAnalysis,TempASent]
    AfterSentAnalysis=pd.concat(CombASent)

AfterSentAnalysis

BeforeSentAnalysis.describe()

AfterSentAnalysis.describe()

#sent analysis on before adjective sentences
BeforeSentAdj=pd.DataFrame()

for i in range(0,len(B_adjph_whole_sentences)):
    sent=sid.polarity_scores(B_adjph_whole_sentences[i])

    B_Sent=B_adjph_whole_sentences[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[B_Sent, Neg, Pos, Neu, Comp]
    TempBSent = pd.DataFrame([TimeForDF],columns=('B_Sent','Negative', 'Positive','Neutral','Compound'))
    CombBSent=[BeforeSentAdj,TempBSent]
    BeforeSentAdj=pd.concat(CombBSent)

#sent analysis on before adverb sentences
BeforeSentAdv=pd.DataFrame()

for i in range(0,len(B_advph_whole_sentences)):
    sent=sid.polarity_scores(B_advph_whole_sentences[i])

    B_Sent=B_advph_whole_sentences[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[B_Sent, Neg, Pos, Neu, Comp]
    TempBSent = pd.DataFrame([TimeForDF],columns=('B_Sent','Negative', 'Positive','Neutral','Compound'))
    CombBSent=[BeforeSentAdv,TempBSent]
    BeforeSentAdv=pd.concat(CombBSent)

#sent analysis on before adjective + adverb sentences
BeforeSentAdjv=pd.DataFrame()

for i in range(0,len(B_adv_adj_phrase_sentences)):
    sent=sid.polarity_scores(B_adv_adj_phrase_sentences[i])

    B_Sent=B_adv_adj_phrase_sentences[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[B_Sent, Neg, Pos, Neu, Comp]
    TempBSent = pd.DataFrame([TimeForDF],columns=('B_Sent','Negative', 'Positive','Neutral','Compound'))
    CombBSent=[BeforeSentAdjv,TempBSent]
    BeforeSentAdjv=pd.concat(CombBSent)

#sent analysis on after adjective sentences
AfterSentAdj=pd.DataFrame()

for i in range(0,len(A_adjph_whole_sentences)):
    sent=sid.polarity_scores(A_adjph_whole_sentences[i])

    A_Sent=A_adjph_whole_sentences[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[A_Sent, Neg, Pos, Neu, Comp]
    TempASent = pd.DataFrame([TimeForDF],columns=('A_Sent','Negative', 'Positive','Neutral','Compound'))
    CombASent=[AfterSentAdj,TempASent]
    AfterSentAdj=pd.concat(CombASent)

#sent analysis on before adverb sentences
AfterSentAdv=pd.DataFrame()

for i in range(0,len(A_advph_whole_sentences)):
    sent=sid.polarity_scores(A_advph_whole_sentences[i])

    A_Sent=A_advph_whole_sentences[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[A_Sent, Neg, Pos, Neu, Comp]
    TempASent = pd.DataFrame([TimeForDF],columns=('A_Sent','Negative', 'Positive','Neutral','Compound'))
    CombASent=[AfterSentAdv,TempASent]
    AfterSentAdv=pd.concat(CombASent)

#sent analysis on before adjective + adverb sentences
AfterSentAdjv=pd.DataFrame()

for i in range(0,len(A_adv_adj_phrase_sentences)):
    sent=sid.polarity_scores(A_adv_adj_phrase_sentences[i])

    A_Sent=A_adv_adj_phrase_sentences[i]
    Neg=sent['neg']
    Pos=sent['pos']
    Neu=sent['neu']
    Comp=sent['compound']
    TimeForDF=[A_Sent, Neg, Pos, Neu, Comp]
    TempASent = pd.DataFrame([TimeForDF],columns=('B_Sent','Negative', 'Positive','Neutral','Compound'))
    CombASent=[AfterSentAdjv,TempASent]
    AfterSentAdjv=pd.concat(CombASent)

print(BeforeSentAnalysis.describe())
print(BeforeSentAdj.describe())
print(BeforeSentAdv.describe())
print(BeforeSentAdjv.describe())

print(AfterSentAnalysis.describe())
print(AfterSentAdj.describe())
print(AfterSentAdv.describe())
print(AfterSentAdjv.describe())