################################################################################
# Matthew Spitulnik ############################################################
# Natural Language Processing ##################################################
# Comparing Corpora with Corpus Statistics #####################################
# Project Summary: The goal of this project was to compare two different documents
#  or sets of text-based data using corpus statistics. We were able to use data 
# of our choosing, so I built Python data mining scripts to collect the Billboard 
# top 100 songs for each year from 1980 through 2020, which was all converted into 
# a data frame structure. I then built additional data mining scripts that used 
# the list of collected song names to go out and download the lyrics for each song, 
# which was then also converted into an easy-to-use data frame. Regex techniques 
# were used to clean up lyric data and remove html formatting, punctuation, special 
# characters, etc., and other data that would not contribute to any kind of analysis. 
# The lyrics for songs written before the year 2000 were then compared to the lyrics 
# for songs written during and after the year 2000 using NLP techniques like 
# tokenization, stop word removal, lemmatizing, and n-gram analysis. I then created 
# a report that communicated the results from the different analysis.
################################################################################

################################################################################
### Install and load required packages #########################################
################################################################################

###Install the required libraries.
#%pip install pandas
#%pip install re
#%pip install requests
#%pip install html5lib
#%pip install nltk
#%pip install contractions
#%pip install lxml
#%pip install bs4

#Import the required libraries
import pandas as pd
import re
import requests
import html5lib
import nltk
#import sys
#!{sys.executable} -m pip install contractions
import contractions
from nltk import FreqDist
from lxml import html
from urllib import request
from urllib.request import Request
from urllib.request import urlopen
from bs4 import BeautifulSoup
from nltk.stem import WordNetLemmatizer
from nltk.collocations import *
nltk.download('stopwords', quiet=True)

################################################################################
### Import the data sets that will be used throughout the code #################
################################################################################

###This creates a "default_directory" variable, where the directory path to the
# data files folder containing all of the required data sets is saved so that it
# does not need to be constantly re-entered. Remember to use forward slashes
# instead of back slashes in the directory path. For example, if the datafiles
# folder is saved in "C:\home\project\datafiles", then "C:/home/project"
# would be inserted between the quotes below.
default_directory = "<DEFAULT DIRECTORY PATH HERE>"

#load the data frames that are created later so that the data mining scripts don't need to be run and waited for
songArtDF = pd.read_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDF.csv')
songArtDFOrg = pd.read_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDFOrg.csv')
songArtLyrics =pd.read_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtLyrics.csv')

################################################################################
### Collect and Clean Required Data ############################################
################################################################################

#start by running some tests to figure out how to collect the lists of top 100 billboard songs from each year.
testyearlink="https://en.wikipedia.org/wiki/Billboard_Year-End_Hot_100_singles_of_1980"
testtables=pd.read_html(testyearlink)
testtables[0]

type(testtables[0])

testtesttables=testtables[0][['Title','Artist(s)']]
testtesttables

testtable2=testtables[0]

testtable2['Year']=1980

testtable2

#now create the script that will go out to wikipedia for the top 100 billboard songs of each year from 1980-2019 and put them into a data frame
songArtDF=pd.DataFrame()
for i in range(1980,2020):
    songArtyear = "https://en.wikipedia.org/wiki/Billboard_Year-End_Hot_100_singles_of_" + str(i)
    temptables=pd.read_html(songArtyear)
    songArttable=temptables[0][['Title','Artist(s)']]
    songArttable['Year']=i

    CombDF=[songArtDF,songArttable]
    songArtDF=pd.concat(CombDF)

songArtDF=songArtDF.reset_index(drop=True)

#####troubleshoot why this script is failing

songArtDF

i

temptables

#####appears that in 2012, a statement was added to the page that acted as a table, testing a way around this below
if 'Title' and 'Artist(s)' in temptables[0]:
    print('yes')
else:
    print('no')

if 'Title' and 'Artist(s)' in temptables[1]:
    print('yes')
else:
    print('no')

#redo the script with above if statement to deal with pages that dont have the required table first
songArtDF=pd.DataFrame()
for i in range(1980,2020):
    songArtyear = "https://en.wikipedia.org/wiki/Billboard_Year-End_Hot_100_singles_of_" + str(i)
    temptables=pd.read_html(songArtyear)
    for h in range(0,len(temptables)):
        if 'Title' and 'Artist(s)' in temptables[h]:
            songArttable=temptables[h][['Title','Artist(s)']]
    songArttable['Year']=i

    CombDF=[songArtDF,songArttable]
    songArtDF=pd.concat(CombDF)

songArtDF=songArtDF.reset_index(drop=True)

#create a column that establishes which document each song will be a part of: before the year 2000 or after it.
for i in songArtDF.index:
    if songArtDF.loc[i,'Year'] <2000:
        songArtDF.loc[i,'Before2000']='Yes'
    else:
        songArtDF.loc[i,'Before2000']='No'

#change the Before2000 column to categorical: this may not be needed but most likely won't hurt
songArtDF=songArtDF.astype({'Before2000':'category'})

songArtDF

###exporting this dataframe so it doesn't need to be created every time
#songArtDF.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDF.csv',index=False)

###now test how to use the data frame to collect each songs lyrics
#azlyrics.com uses the name of the artist with no spaces/punctuation/special characters, so remove those
spaceremovetest= re.sub('[\W]','',songArtDF.loc[3997,'Artist(s)'])
spaceremovetest

songArtDF.loc[3998,'Title']

songArtDF.loc[3342,'Artist(s)']

#same thing for the title of the song
quoteremovetest= re.sub('[\W]','',songArtDF.loc[3997,'Title'])
quoteremovetest

#if a song is performed by an artist, with another artist featured, on azlyrics.com only the primary artist is used. Next few cells will be an if statment to try to deal with this.
lyricURLtest='https://www.azlyrics.com/lyrics/' + spaceremovetest + '/' + quoteremovetest + '.html'
lyricURLtest

#this tests if the initial guess at the song lyrics URL works, and if it doesn't what to do about it
get = requests.get(lyricURLtest)
if get.status_code == 200:
    print('This worked')
else:
    print('This did not work')

get = requests.get(lyricURLtest)
if get.status_code == 200:
    print('This worked')
else:
    URLandMatchTest=re.search(' and ', songArtDF.loc[3997,'Artist(s)'])
    if URLandMatchTest:
        print('This song has and in it')

#now figure out how to remove everything after ' and ' or ' & '
re.findall(' and (?<= and ).*$',songArtDF.loc[3997,'Artist(s)'])

if ' and ' in songArtDF.loc[3997,'Artist(s)']:
    print('Yes')

#try one more
re.findall(' & (?<= & ).*$',songArtDF.loc[3342,'Artist(s)'])

#and one more
re.findall(' featuring (?<= featuring ).*$',songArtDF.loc[3342,'Artist(s)'])

#now try doing this with a re.sub to remove everything after those characters
andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[3997,'Artist(s)'])
andsubremoval

ampsubremoval=re.sub(' & (?<= & ).*$','',songArtDF.loc[3342,'Artist(s)'])
ampsubremoval

featsubremoval=re.sub(' featuring (?<= featuring ).*$','',songArtDF.loc[3342,'Artist(s)'])
featsubremoval

#now get the lyrics from a working URL using the xpatch, or the breakdown of where in the structure of the html the text is located.
#/html/body/div[2]/div[2]/div[2]/div[5]
#/html/body/div[2]/div[2]/div[2]/div[5]
#/html/body/div[2]/div[2]/div[2]/div[5]
templyricsURL='https://www.azlyrics.com/lyrics/barbrastreisand/nomoretearsenoughisenough.html'
templyricshtml=requests.get(templyricsURL)
templyricscontent=html.fromstring(templyricshtml.content)
templyrics=templyricscontent.xpath('/html/body/div[2]/div[2]/div[2]/div[5]/text()')
print(templyrics[5])
templyrics

#now create initial script that will collect all of the lyrics
for i in songArtDF.index:
    artnospace= re.sub('[\W]','',songArtDF.loc[i,'Artist(s)'])
    titlenospace= re.sub('[\W]','',songArtDF.loc[i,'Title'])
    templyricURL='https://www.azlyrics.com/lyrics/' + artnospace + '/' + titlenospace + '.html'
    templyricURL=templyricURL.lower()

    linktest = requests.get(templyricURL)
    if linktest.status_code == 200:
        templyrichtml=requests.get(templyricURL)
        templyriccontent=html.fromstring(templyrichtml.content)
        templyric=str(templyriccontent.xpath('/html/body/div[2]/div[2]/div[2]/div[5]/text()'))
        songArtDF.loc[i,'Lyrics']=templyric
    else:
        if ' and ' in songArtDF.loc[i,'Artist(s)']:
            andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
        else:
            andsubremoval=songArtDF.loc[i,'Artist(s)']
        if ' & ' in andsubremoval:
            ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
        else:
            ampsubremoval=andsubremoval
        if ' featuring ' in ampsubremoval:
            featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
        else:
            featsubremoval=ampsubremoval
        artnospace= re.sub('[\W]','',featsubremoval)
        templyricURL='https://www.azlyrics.com/lyrics/' + artnospace + '/' + titlenospace + '.html'
        templyricURL=templyricURL.lower()
        templyrichtml=requests.get(templyricURL)
        templyriccontent=html.fromstring(templyrichtml.content)
        templyric=str(templyriccontent.xpath('/html/body/div[2]/div[2]/div[2]/div[5]/text()'))
        songArtDF.loc[i,'Lyrics']=templyric

songArtDF.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDF.csv',index=False)

songArtDF

#azlyrics.com started failing after 8 searches, trying songlyrics.com instead
for i in songArtDF.index:
    artnospace=songArtDF.loc[i,'Artist(s)'].replace(',','')
    artnospace= re.sub('[\W]','-',artnospace)
    titlenospace=songArtDF.loc[i,'Title'].replace(',','')
    titlenospace= re.sub('[\W]','-',titlenospace)
    templyricURL='https://www.songlyrics.com/' + artnospace + '/' + titlenospace + '/'
    templyricURL=templyricURL.lower()

    linktest = requests.get(templyricURL)
    if linktest.status_code == 200:
        templyrichtml=requests.get(templyricURL)
        templyriccontent=html.fromstring(templyrichtml.content)
        templyric=str(templyriccontent.xpath('//*[@id="songLyricsDiv"]'))
        songArtDF.loc[i,'Lyrics']=templyric
    else:
        if ' and ' in songArtDF.loc[i,'Artist(s)']:
            andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
        else:
            andsubremoval=songArtDF.loc[i,'Artist(s)']
        if ' & ' in andsubremoval:
            ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
        else:
            ampsubremoval=andsubremoval
        if ' featuring ' in ampsubremoval:
            featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
        else:
            featsubremoval=ampsubremoval
        artnospace=featsubremoval.replace(',','')
        artnospace= re.sub('[\W]','-',artnospace)
        templyricURL='https://www.songlyrics.com/' + artnospace + '/' + titlenospace + '/'
        templyricURL=templyricURL.lower()
        templyrichtml=requests.get(templyricURL)
        templyriccontent=html.fromstring(templyrichtml.content)
        templyric=str(templyriccontent.xpath('//*[@id="songLyricsDiv"]'))
        songArtDF.loc[i,'Lyrics']=templyric

#the structure of songlyrics.com ULRs gave me some trouble, may need to try another site again
testpolice=re.sub('^The ','',songArtDF.loc[156,'Artist(s)'])

firstletter=testpolice[0].lower()
print(type(firstletter))
firstletter

thetest = re.match('^The ', songArtDF.loc[156,'Artist(s)'])
if thetest:
    print(True)
else:
    print(False)

#had issues with songlyrics.com also, trying one more site, lyricsondemand.com
for i in songArtDF.index:
    theremoval=re.sub('^The ','',songArtDF.loc[i,'Artist(s)'])
    firstletter=theremoval[0].lower()
    artnospace= re.sub('[\W]','',theremoval)
    titlenospace= re.sub('[\W]','',songArtDF.loc[i,'Title'])
    templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
    templyricURL=templyricURL.lower()

    linktest = requests.get(templyricURL)
    if linktest.status_code == 200:
        templyrichtml=requests.get(templyricURL)
        templyriccontent=html.fromstring(templyrichtml.content)
        templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[3]/text()'))
        songArtDF.loc[i,'Lyrics']=templyric
    else:
        thetest = re.match('^The ', songArtDF.loc[i,'Artist(s)'])
        if thetest:
            artnospace= re.sub('[\W]','',songArtDF.loc[i,'Artist(s)'])
            templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
            templyricURL=templyricURL.lower()

            linktest = requests.get(templyricURL)
            if linktest.status_code == 200:
                templyrichtml=requests.get(templyricURL)
                templyriccontent=html.fromstring(templyrichtml.content)
                templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[3]/text()'))
                songArtDF.loc[i,'Lyrics']=templyric
            else:
                if ' and ' in songArtDF.loc[i,'Artist(s)']:
                    andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                else:
                    andsubremoval=songArtDF.loc[i,'Artist(s)']
                if ' & ' in andsubremoval:
                    ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                else:
                    ampsubremoval=andsubremoval
                if ' featuring ' in ampsubremoval:
                    featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                else:
                    featsubremoval=ampsubremoval
                    artnospace= re.sub('[\W]','',featsubremoval)
        else:
            if ' and ' in songArtDF.loc[i,'Artist(s)']:
                andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
            else:
                andsubremoval=songArtDF.loc[i,'Artist(s)']
            if ' & ' in andsubremoval:
                ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
            else:
                ampsubremoval=andsubremoval
            if ' featuring ' in ampsubremoval:
                featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
            else:
                featsubremoval=ampsubremoval
                artnospace= re.sub('[\W]','',featsubremoval)
        templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
        templyricURL=templyricURL.lower()
        templyrichtml=requests.get(templyricURL)
        templyriccontent=html.fromstring(templyrichtml.content)
        templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[3]/text()'))
        songArtDF.loc[i,'Lyrics']=templyric

songArtDF.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDF.csv',index=False)

###some songs were collected, but a large number did not work, troubleshooting again

templyricURL

linktest = requests.get(templyricURL)
if linktest.status_code == 200:
    print('TRUE')

if thetest:
    print('TRUE')

print(artnospace)
print(songArtDF.loc[i,'Artist(s)'])
andsubremoval

templyricsSTR=str(templyrics)
print(templyricsSTR)
templyricsSTR

templyricsSTRsoup = BeautifulSoup(templyricsSTR, 'html.parser')
print(type(templyricsSTRsoup))
templyricsSTRsoup

#looking at another link
templyricsURL='https://www.azlyrics.com/lyrics/macklemore/samelove.html'
templyricshtml=requests.get(templyricsURL)
templyricscontent=html.fromstring(templyricshtml.content)
templyrics=templyricscontent.xpath('/html/body/div[2]/div[2]/div[2]/div[5]/text()')
print(templyrics)
templyricsSTR=str(templyrics)
templyricsSTR

for i in songArtDF.index:
    if songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\\n\']' or songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\']':
        print(songArtDF.loc[i,'Lyrics'], ' || ','//*[@id="sbmtlyr"]')

for i in songArtDF.index:
    if songArtDF.loc[i,'Lyrics']=='[]':
        print(songArtDF.loc[i,'Lyrics'], ' || ','//*[@id="ldata"]/div[4]')

#a large number of songs didn't work, the xpath to the song lyric text appears to be different for many of those songs, adjusting script to fill in the lyrics that didn't work
for i in songArtDF.index:
    if songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\\n\']' or songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\']' or songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\']':
        theremoval=re.sub('^The ','',songArtDF.loc[i,'Artist(s)'])
        firstletter=theremoval[0].lower()
        artnospace= re.sub('[\W]','',theremoval)
        titlenospace= re.sub('[\W]','',songArtDF.loc[i,'Title'])
        templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
        templyricURL=templyricURL.lower()

        linktest = requests.get(templyricURL)
        if linktest.status_code == 200:
            templyrichtml=requests.get(templyricURL)
            templyriccontent=html.fromstring(templyrichtml.content)
            templyric=str(templyriccontent.xpath('//*[@id="sbmtlyr"]/text()'))
            songArtDF.loc[i,'Lyrics']=templyric
        else:
            thetest = re.match('^The ', songArtDF.loc[i,'Artist(s)'])
            if thetest:
                artnospace= re.sub('[\W]','',songArtDF.loc[i,'Artist(s)'])
                templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
                templyricURL=templyricURL.lower()

                linktest = requests.get(templyricURL)
                if linktest.status_code == 200:
                    templyrichtml=requests.get(templyricURL)
                    templyriccontent=html.fromstring(templyrichtml.content)
                    templyric=str(templyriccontent.xpath('//*[@id="sbmtlyr"]/text()'))
                    songArtDF.loc[i,'Lyrics']=templyric
                else:
                    if ' and ' in songArtDF.loc[i,'Artist(s)']:
                        andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                    else:
                        andsubremoval=songArtDF.loc[i,'Artist(s)']
                    if ' & ' in andsubremoval:
                        ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                    else:
                        ampsubremoval=andsubremoval
                    if ' featuring ' in ampsubremoval:
                        featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                    else:
                        featsubremoval=ampsubremoval
                    artnospace= re.sub('[\W]','',featsubremoval)
            else:
                if ' and ' in songArtDF.loc[i,'Artist(s)']:
                    andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                else:
                    andsubremoval=songArtDF.loc[i,'Artist(s)']
                if ' & ' in andsubremoval:
                    ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                else:
                    ampsubremoval=andsubremoval
                if ' featuring ' in ampsubremoval:
                    featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                else:
                    featsubremoval=ampsubremoval
                artnospace= re.sub('[\W]','',featsubremoval)
            templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
            templyricURL=templyricURL.lower()
            templyrichtml=requests.get(templyricURL)
            templyriccontent=html.fromstring(templyrichtml.content)
            templyric=str(templyriccontent.xpath('//*[@id="sbmtlyr"]/text()'))
            songArtDF.loc[i,'Lyrics']=templyric
    else:
        if songArtDF.loc[i,'Lyrics']=='[]':
            theremoval=re.sub('^The ','',songArtDF.loc[i,'Artist(s)'])
            firstletter=theremoval[0].lower()
            artnospace= re.sub('[\W]','',theremoval)
            titlenospace= re.sub('[\W]','',songArtDF.loc[i,'Title'])
            templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
            templyricURL=templyricURL.lower()

            linktest = requests.get(templyricURL)
            if linktest.status_code == 200:
                templyrichtml=requests.get(templyricURL)
                templyriccontent=html.fromstring(templyrichtml.content)
                templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[4]/text()'))
                songArtDF.loc[i,'Lyrics']=templyric
            else:
                thetest = re.match('^The ', songArtDF.loc[i,'Artist(s)'])
                if thetest:
                    artnospace= re.sub('[\W]','',songArtDF.loc[i,'Artist(s)'])
                    templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
                    templyricURL=templyricURL.lower()

                    linktest = requests.get(templyricURL)
                    if linktest.status_code == 200:
                        templyrichtml=requests.get(templyricURL)
                        templyriccontent=html.fromstring(templyrichtml.content)
                        templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[4]/text()'))
                        songArtDF.loc[i,'Lyrics']=templyric
                    else:
                        if ' and ' in songArtDF.loc[i,'Artist(s)']:
                            andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                        else:
                            andsubremoval=songArtDF.loc[i,'Artist(s)']
                        if ' & ' in andsubremoval:
                            ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                        else:
                            ampsubremoval=andsubremoval
                        if ' featuring ' in ampsubremoval:
                            featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                        else:
                            featsubremoval=ampsubremoval
                        artnospace= re.sub('[\W]','',featsubremoval)
                else:
                    if ' and ' in songArtDF.loc[i,'Artist(s)']:
                        andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                    else:
                        andsubremoval=songArtDF.loc[i,'Artist(s)']
                    if ' & ' in andsubremoval:
                        ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                    else:
                        ampsubremoval=andsubremoval
                    if ' featuring ' in ampsubremoval:
                        featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                    else:
                        featsubremoval=ampsubremoval
                    artnospace= re.sub('[\W]','',featsubremoval)
                templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
                templyricURL=templyricURL.lower()
                templyrichtml=requests.get(templyricURL)
                templyriccontent=html.fromstring(templyrichtml.content)
                templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[4]/text()'))
                songArtDF.loc[i,'Lyrics']=templyric

print(templyriccontent)
templyric

songArtDF.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDF.csv',index=False)

songArtDF

templyricURL='https://www.lyricsondemand.com/n/nickjonaslyrics/jealouslyrics.html'
templyricURL=templyricURL.lower()
templyrichtml=requests.get(templyricURL)
templyriccontent=html.fromstring(templyrichtml.content)
templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[4]/text()'))
templyric

#still didn't get a bunch of songs, realized the syntax for some of the if statements were incorrect, corrected those
for i in range(3921,3922):
    if songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\\n\']' or songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\']' or songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\']':
        theremoval=re.sub('^The ','',songArtDF.loc[i,'Artist(s)'])
        firstletter=theremoval[0].lower()
        artnospace= re.sub('[\W]','',theremoval)
        titlenospace= re.sub('[\W]','',songArtDF.loc[i,'Title'])
        templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
        templyricURL=templyricURL.lower()

        linktest = requests.get(templyricURL)
        if linktest.status_code == 200:
            templyrichtml=requests.get(templyricURL)
            templyriccontent=html.fromstring(templyrichtml.content)
            templyric=str(templyriccontent.xpath('//*[@id="sbmtlyr"]/text()'))
            #songArtDF.loc[i,'Lyrics']=templyric
            print(1)
        else:
            thetest = re.match('^The ', songArtDF.loc[i,'Artist(s)'])
            if thetest:
                artnospace= re.sub('[\W]','',songArtDF.loc[i,'Artist(s)'])
                templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
                templyricURL=templyricURL.lower()

                linktest = requests.get(templyricURL)
                if linktest.status_code == 200:
                    templyrichtml=requests.get(templyricURL)
                    templyriccontent=html.fromstring(templyrichtml.content)
                    templyric=str(templyriccontent.xpath('//*[@id="sbmtlyr"]/text()'))
                    #songArtDF.loc[i,'Lyrics']=templyric
                    print(2)
                else:
                    if ' and ' in songArtDF.loc[i,'Artist(s)']:
                        andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                    else:
                        andsubremoval=songArtDF.loc[i,'Artist(s)']
                    if ' & ' in andsubremoval:
                        ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                    else:
                        ampsubremoval=andsubremoval
                    if ' featuring ' in ampsubremoval:
                        featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                    else:
                        featsubremoval=ampsubremoval
                    artnospace= re.sub('[\W]','',featsubremoval)
            else:
                if ' and ' in songArtDF.loc[i,'Artist(s)']:
                    andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                else:
                    andsubremoval=songArtDF.loc[i,'Artist(s)']
                if ' & ' in andsubremoval:
                    ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                else:
                    ampsubremoval=andsubremoval
                if ' featuring ' in ampsubremoval:
                    featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                else:
                    featsubremoval=ampsubremoval
                artnospace= re.sub('[\W]','',featsubremoval)
            templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
            templyricURL=templyricURL.lower()
            templyrichtml=requests.get(templyricURL)
            templyriccontent=html.fromstring(templyrichtml.content)
            #templyric=str(templyriccontent.xpath('//*[@id="sbmtlyr"]/text()'))
            templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[4]/text()'))
            #songArtDF.loc[i,'Lyrics']=templyric
            print(3)
    else:
        if songArtDF.loc[i,'Lyrics']=='[]':
            theremoval=re.sub('^The ','',songArtDF.loc[i,'Artist(s)'])
            firstletter=theremoval[0].lower()
            artnospace= re.sub('[\W]','',theremoval)
            titlenospace= re.sub('[\W]','',songArtDF.loc[i,'Title'])
            templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
            templyricURL=templyricURL.lower()

            linktest = requests.get(templyricURL)
            if linktest.status_code == 200:
                templyrichtml=requests.get(templyricURL)
                templyriccontent=html.fromstring(templyrichtml.content)
                templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[4]/text()'))
                #songArtDF.loc[i,'Lyrics']=templyric
                print(4)
            else:
                thetest = re.match('^The ', songArtDF.loc[i,'Artist(s)'])
                if thetest:
                    artnospace= re.sub('[\W]','',songArtDF.loc[i,'Artist(s)'])
                    templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
                    templyricURL=templyricURL.lower()

                    linktest = requests.get(templyricURL)
                    if linktest.status_code == 200:
                        templyrichtml=requests.get(templyricURL)
                        templyriccontent=html.fromstring(templyrichtml.content)
                        templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[5]/text()'))
                        #songArtDF.loc[i,'Lyrics']=templyric
                        print(5)
                    else:
                        if ' and ' in songArtDF.loc[i,'Artist(s)']:
                            andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                        else:
                            andsubremoval=songArtDF.loc[i,'Artist(s)']
                        if ' & ' in andsubremoval:
                            ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                        else:
                            ampsubremoval=andsubremoval
                        if ' featuring ' in ampsubremoval:
                            featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                        else:
                            featsubremoval=ampsubremoval
                        artnospace= re.sub('[\W]','',featsubremoval)
                else:
                    if ' and ' in songArtDF.loc[i,'Artist(s)']:
                        andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
                    else:
                        andsubremoval=songArtDF.loc[i,'Artist(s)']
                    if ' & ' in andsubremoval:
                        ampsubremoval=re.sub(' & (?<= & ).*$','',andsubremoval)
                    else:
                        ampsubremoval=andsubremoval
                    if ' featuring ' in ampsubremoval:
                        featsubremoval=re.sub(' featuring (?<= featuring ).*$','',ampsubremoval)
                    else:
                        featsubremoval=ampsubremoval
                    artnospace= re.sub('[\W]','',featsubremoval)
                templyricURL='https://www.lyricsondemand.com/' + firstletter + '/' + artnospace + 'lyrics/' + titlenospace + 'lyrics.html'
                templyricURL=templyricURL.lower()
                templyrichtml=requests.get(templyricURL)
                templyriccontent=html.fromstring(templyrichtml.content)
                templyric=str(templyriccontent.xpath('//*[@id="ldata"]/div[4]/text()'))
                #songArtDF.loc[i,'Lyrics']=templyric
                print(6)

###still missing around 750 songs, more troubleshooting

templyricURL

featsubremoval

artnospace

titlenospace

templyric

songArtDF.loc[30,'Lyrics']='[\'\\n\', \'\\n\']'

songArtDF.loc[i,'Lyrics']

print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\']'])
print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\\n\']'])
print(songArtDF['Lyrics'].value_counts()['[]'])

print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\']'])
print(songArtDF['Lyrics'].value_counts()['[]'])

req = Request(
    url='https://www.lyricsondemand.com/m/maroon5lyrics/girlslikeyoulyrics.html',
    headers={'User-Agent': 'Mozilla/5.0'}
)
webpage = urlopen(req).read()
type(webpage)

testyear = "https://www.lyricsondemand.com/k/kennyrogerslyrics/dontfallinlovewithadreamerlyrics.html"
#testResponse =request.urlopen(testyear)
#testHTML = testResponse.read().decode('utf8')
#testsoup = BeautifulSoup(testHTML, 'html.parser')
testsoup = BeautifulSoup(webpage, 'html.parser')
testsoupCLASS=testsoup.find_all('div', class_='lcontent')
testsoupCLASS

testsoup.find('div', class_='lcontent').text

webpage

webpage = requests.get('https://www.lyricsondemand.com/m/maroon5lyrics/girlslikeyoulyrics.html',headers={'User-Agent': 'Mozilla/5.0'})
testsoup = BeautifulSoup(webpage.text, 'lxml')
testsoup.body.get_text(' ', strip=True)

for i in songArtDF.index:
    if songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\\n\']' or songArtDF.loc[i,'Lyrics']=='[\'\\n\', \'\\n\']' or songArtDF.loc[i,'Lyrics']=='[]' or songArtDF.loc[i,'Lyrics']=='[\'\\n\']':
        songArtDF.loc[i,'Lyrics']='[]'

#print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\']'])
#print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\\n\']'])
print(songArtDF['Lyrics'].value_counts()['[]'])
#print(songArtDF['Lyrics'].value_counts()['[\'\\n\']'])

print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\']'])
print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\\n\']'])
print(songArtDF['Lyrics'].value_counts()['[]'])
print(songArtDF['Lyrics'].value_counts()['[\'\\n\']'])

templyricURL

songArtDF

#determined that the structure of some pages from lyricsondemand.com did not allow for the song lyric tests to be downloaded, going back to songlyrics.com to try to get as many remaining songs as possible
for i in songArtDF.index:
#for i in range(3979,3980):
    if songArtDF.loc[i,'Lyrics']=='[]':
        artnospace=songArtDF.loc[i,'Artist(s)'].replace(',','')
        artnospace= re.sub('[\W]','-',artnospace)
        titlenospace=re.sub('^"','',songArtDF.loc[i,'Title'])
        titlenospace=titlenospace.replace(',','')
        titlenospace= re.sub('[\W]','-',titlenospace)
        templyricURL='https://www.songlyrics.com/' + artnospace + '/' + titlenospace + 'lyrics/'
        templyricURL=templyricURL.lower()

        linktest = requests.get(templyricURL)
        if linktest.status_code == 200:
            templyrichtml=requests.get(templyricURL)
            templyriccontent=html.fromstring(templyrichtml.content)
            templyric=str(templyriccontent.xpath('//*[@id="songLyricsDiv"]/text()'))
            songArtDF.loc[i,'Lyrics']=templyric
            #print(1)

songArtDF.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDF.csv',index=False)

for i in songArtDF.index:
    if 'We do not have the lyrics for' in songArtDF.loc[i,'Lyrics']:
        songArtDF.loc[i,'Lyrics']='[]'

for i in songArtDF.index:
#for i in range(3925,3926):
    if songArtDF.loc[i,'Lyrics']=='[]':
        if ' and ' in songArtDF.loc[i,'Artist(s)']:
            featart=re.findall('(?<= and ).*$', songArtDF.loc[i,'Artist(s)'])
            featart=str(featart[0])
            andsubremoval=re.sub(' and (?<= and ).*$','',songArtDF.loc[i,'Artist(s)'])
            featadd=andsubremoval+'-feat-'+featart
        elif ' & ' in songArtDF.loc[i,'Artist(s)']:
            featart=re.findall('(?<= & ).*$', songArtDF.loc[i,'Artist(s)'])
            featart=str(featart[0])
            ampsubremoval=re.sub(' & (?<= & ).*$','',songArtDF.loc[i,'Artist(s)'])
            featadd=ampsubremoval+'-feat-'+featart
        elif ' featuring ' in songArtDF.loc[i,'Artist(s)']:
            featart=re.findall('(?<= featuring ).*$', songArtDF.loc[i,'Artist(s)'])
            featart=str(featart[0])
            featsubremoval=re.sub(' featuring (?<= featuring ).*$','',songArtDF.loc[i,'Artist(s)'])
            featadd=featsubremoval+'-feat-'+featart
        else:
            featadd=songArtDF.loc[i,'Artist(s)']
        artnospace=featadd.replace(',','')
        artnospace= re.sub('[\W]','-',artnospace)
        titlenospace=re.sub('^"','',songArtDF.loc[i,'Title'])
        titlenospace=titlenospace.replace(',','')
        titlenospace= re.sub('[\W]','-',titlenospace)
        templyricURL='https://www.songlyrics.com/' + artnospace + '/' + titlenospace + 'lyrics/'
        templyricURL=templyricURL.lower()

        linktest = requests.get(templyricURL)
        if linktest.status_code == 200:
            templyrichtml=requests.get(templyricURL)
            templyriccontent=html.fromstring(templyrichtml.content)
            templyric=str(templyriccontent.xpath('//*[@id="songLyricsDiv"]/text()'))
            songArtDF.loc[i,'Lyrics']=templyric

#print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\']'])
#print(songArtDF['Lyrics'].value_counts()['[\'\\n\', \'\\n\\n\']'])
print(songArtDF['Lyrics'].value_counts()['[]'])
#print(songArtDF['Lyrics'].value_counts()['[\'\\n\']'])

for i in songArtDF.index:
    if 'We do not have the lyrics for' in songArtDF.loc[i,'Lyrics']:
        songArtDF.loc[i,'Lyrics']='[]'

titlenospace

templyric

templyricURL

songArtDF.loc[23,'Title']

songArtDF.loc[23,'Title'].replace(',','')

re.sub('[\W]','-',titlenospace)

re.findall('(?<= featuring ).*$', songArtDF.loc[3917,'Artist(s)'])

re.findall('(?<= and ).*$', songArtDF.loc[3925,'Artist(s)'])

########Able to get the list down to only 200 song lyrics missing, going to do cleanup of the lyrics now
#IMPORTANT NOTE# Because it took so many intermittent steps to get as many of the song lyrics as possible
# collected, the final result of this work was exported so that it could then just be imported without having
# to wait for all of the above data mining scripts to finish. There is code to import the resulting file at the
# top of the page already, and the name of that file is songArtDF.

#make a copy of song list as is before editting
songArtDFOrg=songArtDF.copy(deep=True)
songArtDFOrg.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtDFOrg.csv',index=False)

#remove songs with no lyrics and reset the index
songArtLyrics=songArtDF[songArtDF['Lyrics'] != '[]']
songArtLyrics=songArtLyrics.reset_index(drop=True)

songArtLyrics.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtLyrics.csv',index=False)

#figure out how many songs we found lyrics for before and after 2000
print(songArtLyrics['Before2000'].value_counts()['Yes']) #1951 songs before 2000
print(songArtLyrics['Before2000'].value_counts()['No']) #1849 songs after 2000

songArtLyrics

#remove line breaks
for i in songArtLyrics.index:
    songArtLyrics.loc[i,'Lyrics']=songArtLyrics.loc[i,'Lyrics'].replace('\\n','')
    songArtLyrics.loc[i,'Lyrics']=songArtLyrics.loc[i,'Lyrics'].replace('\\r','')
    songArtLyrics.loc[i,'Lyrics']=songArtLyrics.loc[i,'Lyrics'].replace('\\','')

#remove contractions
for i in songArtLyrics.index:
    songArtLyrics.loc[i,'Lyrics']=contractions.fix(songArtLyrics.loc[i,'Lyrics'])

#everything lowercase:
for i in songArtLyrics.index:
    songArtLyrics.loc[i,'Lyrics']=songArtLyrics.loc[i,'Lyrics'].lower()

#remove punctuation
for i in songArtLyrics.index:
    songArtLyrics.loc[i,'Lyrics']=re.sub(r'[^\w\s]','',songArtLyrics.loc[i,'Lyrics'])

songArtLyrics.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtLyrics.csv',index=False)

################################################################################
### Perform Analysis of Data ###################################################
################################################################################

#turn all of the lyrics into two different corpus's, one of the songs before 2000, one of the lyrics from after 2000
#first before 2000
'''before2000corp=[]
after2000corp=[]
for i in songArtLyrics.index:
    titlenospace= re.sub('[\W]','',songArtLyrics.loc[i,'Title'])
    locals()[titlenospace]=songArtLyrics.loc[i,'Lyrics']
    if songArtLyrics.loc[i,'Before2000']=='Yes':
        before2000corp.append(titlenospace)
    else:
        before2000corp.append(titlenospace)'''

#instead of a corpus, combine all the lyrics into two lists of lyrics, before 2000 and after 2000. The order of the lyrics will not change, so bigram measurements can still be done later
before2000lyr=[]
after2000lyr=[]
for i in songArtLyrics.index:
    if songArtLyrics.loc[i,'Before2000']=='Yes':
        before2000lyr.append(songArtLyrics.loc[i,'Lyrics'])
    else:
        after2000lyr.append(songArtLyrics.loc[i,'Lyrics'])

#tokenize the before 2000 words
before2000TOK=nltk.word_tokenize(str(before2000lyr))

print(len(before2000TOK))
len(before2000TOK)/1951

#tokenize the after 2000 words
after2000TOK=nltk.word_tokenize(str(after2000lyr))

print(len(after2000TOK))
len(after2000TOK)/1849

after2000TOK

#remove stop words
stopwords=nltk.corpus.stopwords.words('english')
before2000stop = [w for w in before2000TOK if not w in stopwords]
after2000stop = [w for w in after2000TOK if not w in stopwords]

print(len(before2000stop))
print(len(before2000stop)/1951)
print(len(after2000stop))
print(len(after2000stop)/1849)

#see how affective lemmatization is
lemmatizer = WordNetLemmatizer()
before2000lem=[]
for i in before2000stop:
    before2000lem.append(lemmatizer.lemmatize(i))

after2000lem=[]
for i in after2000stop:
    after2000lem.append(lemmatizer.lemmatize(i))

print(len(before2000lem))
print(len(after2000lem))

before2000stop

before2000lem

songArtLyrics.to_csv(f'{default_directory}/Comparing Corpora With Corpus Statistics/datafiles/songArtLyrics.csv',index=False)

#now create frequency distributions. as seen below, the songs in before 2000s and after 2000s have very similar frequent words
beforeDist=FreqDist(before2000stop)
afterDist=FreqDist(after2000stop)

beforeDist

afterDist

beforeDist_nitems=beforeDist.most_common(50)
afterDist_nitems=afterDist.most_common(50)

beforeDist_nitems

afterDist_nitems

#create basic brigrams below
before2000bi=list(nltk.bigrams(nltk.word_tokenize(str(before2000lyr))))
after2000bi=list(nltk.bigrams(nltk.word_tokenize(str(after2000lyr))))

before2000bi[:50]

after2000bi[:50]

#now create more measurable bigrams with collocations package
bigram_measures = nltk.collocations.BigramAssocMeasures()

before2000_finder=BigramCollocationFinder.from_words(nltk.word_tokenize(str(before2000lyr)))
after2000_finder=BigramCollocationFinder.from_words(nltk.word_tokenize(str(after2000lyr)))

before2000_scored=before2000_finder.score_ngrams(bigram_measures.raw_freq)
after2000_scored=after2000_finder.score_ngrams(bigram_measures.raw_freq)

before2000_scored[:50]

after2000_scored[:50]

#remove stop words from both bigrams
before2000_finder.apply_word_filter(lambda w: w in stopwords)
after2000_finder.apply_word_filter(lambda w: w in stopwords)

before2000_scored=before2000_finder.score_ngrams(bigram_measures.raw_freq)
after2000_scored=after2000_finder.score_ngrams(bigram_measures.raw_freq)

before2000_scored[:50]

after2000_scored[:50]

#apply a frequency filter of 5 times
before2000_finder_filt=BigramCollocationFinder.from_words(nltk.word_tokenize(str(before2000lyr)))
after2000_finder_filt=BigramCollocationFinder.from_words(nltk.word_tokenize(str(after2000lyr)))

before2000_finder_filt.apply_freq_filter(5)
after2000_finder_filt.apply_freq_filter(5)

#remove stopwords again
before2000_finder_filt.apply_word_filter(lambda w: w in stopwords)
after2000_finder_filt.apply_word_filter(lambda w: w in stopwords)

#remove words that are three letters or less
before2000_finder_filt.apply_ngram_filter(lambda w1, w2: len(w1) < 4)
before2000_finder_filt.apply_ngram_filter(lambda w1, w2: len(w2) < 4)
after2000_finder_filt.apply_ngram_filter(lambda w1, w2: len(w1) < 4)
after2000_finder_filt.apply_ngram_filter(lambda w1, w2: len(w2) < 4)

before2000_scored_filt=before2000_finder_filt.score_ngrams(bigram_measures.raw_freq)
after2000_scored_filt=after2000_finder_filt.score_ngrams(bigram_measures.raw_freq)

before2000_scored_filt[:50]

after2000_scored_filt[:50]

#now compare PMI scores
before2000_finder_pmi=BigramCollocationFinder.from_words(nltk.word_tokenize(str(before2000lyr)))
after2000_finder_pmi=BigramCollocationFinder.from_words(nltk.word_tokenize(str(after2000lyr)))

before2000_finder_pmi.apply_freq_filter(5)
after2000_finder_pmi.apply_freq_filter(5)

#remove stopwords again
before2000_finder_pmi.apply_word_filter(lambda w: w in stopwords)
after2000_finder_pmi.apply_word_filter(lambda w: w in stopwords)

#remove words that are three letters or less
before2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w1) < 4)
before2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w2) < 4)
after2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w1) < 4)
after2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w2) < 4)

before2000_scored_pmi=before2000_finder_pmi.score_ngrams(bigram_measures.pmi)
after2000_scored_pmi=after2000_finder_pmi.score_ngrams(bigram_measures.pmi)

before2000_scored_pmi[:50]

after2000_scored_pmi[:50]

#now compare PMI scores
before2000_finder_pmi=BigramCollocationFinder.from_words(nltk.word_tokenize(str(before2000lyr)))
after2000_finder_pmi=BigramCollocationFinder.from_words(nltk.word_tokenize(str(after2000lyr)))

before2000_finder_pmi.apply_freq_filter(10)
after2000_finder_pmi.apply_freq_filter(10)

#remove stopwords again
before2000_finder_pmi.apply_word_filter(lambda w: w in stopwords)
after2000_finder_pmi.apply_word_filter(lambda w: w in stopwords)

#remove words that are three letters or less
before2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w1) < 4)
before2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w2) < 4)
after2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w1) < 4)
after2000_finder_pmi.apply_ngram_filter(lambda w1, w2: len(w2) < 4)

before2000_scored_pmi=before2000_finder_pmi.score_ngrams(bigram_measures.pmi)
after2000_scored_pmi=after2000_finder_pmi.score_ngrams(bigram_measures.pmi)

before2000_scored_pmi[:50]

after2000_scored_pmi[:50]